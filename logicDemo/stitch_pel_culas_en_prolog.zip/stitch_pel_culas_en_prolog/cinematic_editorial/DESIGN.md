---
name: Cinematic Editorial
colors:
  surface: '#111317'
  surface-dim: '#111317'
  surface-bright: '#37393e'
  surface-container-lowest: '#0c0e12'
  surface-container-low: '#1a1c20'
  surface-container: '#1e2024'
  surface-container-high: '#282a2e'
  surface-container-highest: '#333539'
  on-surface: '#e2e2e8'
  on-surface-variant: '#d4c4af'
  inverse-surface: '#e2e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#9c8f7b'
  outline-variant: '#504535'
  surface-tint: '#f9bc45'
  primary: '#ffda9c'
  on-primary: '#422d00'
  primary-container: '#f5b942'
  on-primary-container: '#6a4a00'
  inverse-primary: '#7c5800'
  secondary: '#c4c6d0'
  on-secondary: '#2d3038'
  secondary-container: '#44474f'
  on-secondary-container: '#b3b5be'
  tertiary: '#dddfe7'
  on-tertiary: '#2d3037'
  tertiary-container: '#c1c3cb'
  on-tertiary-container: '#4e5057'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdea8'
  primary-fixed-dim: '#f9bc45'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#e0e2ec'
  secondary-fixed-dim: '#c4c6d0'
  on-secondary-fixed: '#191c23'
  on-secondary-fixed-variant: '#44474f'
  tertiary-fixed: '#e1e2ea'
  tertiary-fixed-dim: '#c4c6ce'
  on-tertiary-fixed: '#191c21'
  on-tertiary-fixed-variant: '#44474d'
  background: '#111317'
  on-background: '#e2e2e8'
  surface-variant: '#333539'
typography:
  display-xl:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg:
    fontFamily: Playfair Display
    fontSize: 44px
    fontWeight: '600'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2.5rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
---

## Brand & Style

This design system establishes a professional, editorial, cinema-inspired aesthetic designed for high-end film streaming platforms, curated media libraries, and cinematic archives. The visual language evokes the moody elegance of a darkened theater, utilizing high-contrast typography, deep immersive backgrounds, and intentional warm amber lighting to draw focus to critical actions.

The target audience consists of cinephiles, critics, and premium consumers who expect a sophisticated, immersive digital experience. The UI should evoke a sense of anticipation, sophistication, and intellectual engagement—balancing the timeless authority of editorial journalism with the immersive atmosphere of modern cinema.

The design style is a refined fusion of **Minimalism** and **High-Contrast Editorial**, driven by heavy negative space, restrained color palettes, high-precision typography pairings, and subtle low-contrast outlines.

## Colors

The color architecture is built for an immersive dark-mode environment, establishing strong visual hierarchy through precise tonal contrast.

- **Primary Accent (`#f5b942`):** A warm amber used strictly for high-priority actions, active states, ratings, and critical highlights. It acts as the theater light in the dark.
- **Surface Elevation (`#181b22`):** Used for elevated cards, modal containers, and interactive panels, lifting content cleanly away from the deepest layer.
- **Subtle Borders (`#272a30`):** Low-contrast border tones that delineate containers without introducing visual noise.
- **Background (`#0f1115`):** A near-black canvas that recedes completely, maximizing the perceived vibrancy of media assets.
- **Text Hierarchy:** Primary text utilizes a soft off-white (`#f3f4f6`) to reduce reading fatigue, while secondary text relies on a muted gray (`#9ca3af`) for metadata, timestamps, and supporting labels.

## Typography

The typographic hierarchy pairs the literary authority of **Playfair Display** for headlines, film titles, and editorial callouts with the neutral, utilitarian precision of **Inter** for body copy and metadata. 

For responsive viewports, display sizes scaling above 32px must gracefully collapse on mobile devices (e.g., `display-lg` shifting to 36px) to maintain editorial rhythm without breaking container bounds. Metadata and overlines should consistently employ uppercase styling with tracked-out letter spacing (`0.05em` to `0.08em`) to reinforce the cinematic catalog aesthetic.

## Layout & Spacing

The layout philosophy relies on a **Fluid Grid** system anchored by generous, cinema-inspired whitespace. Content breathes within a 12-column structure featuring 24px gutters and expansive 40px+ outer margins on desktop views, allowing rich visual assets to take center stage.

Spacing scales upward to create deliberate pacing between editorial blocks. On mobile viewports, outer margins scale down to 16px while preserving internal component padding to maintain touch target ergonomics.

## Elevation & Depth

Depth is conveyed primarily through **Tonal Layers** combined with **Low-Contrast Outlines** rather than heavy drop shadows. 

Surfaces step forward from the near-black background (`#0f1115`) to elevated card containers (`#181b22`), delineated cleanly by subtle borders (`#272a30`). Shadows are kept exceptionally sparse, faint, and tinted with deep charcoal tones only when elements float above the canvas (such as active dropdowns, sticky navigation bars, or modal dialogues). This approach keeps the interface feeling flat yet dimensional, matching the tactile quality of high-end print portfolios and modern streaming interfaces.

## Shapes

The design system adopts a **Rounded (12px)** shape language for container elements, striking a balance between modern fluidity and architectural precision. 

Primary card components, modals, and large input fields feature a consistent 12px border radius. Smaller interactive elements such as buttons, badges, and chips use a tighter 6px radius to signal interactability while maintaining alignment with the overall grid geometry. Perfect circles (100% radius) are reserved strictly for avatar treatments and play-action trigger icons.

## Components

### Buttons
Primary actions utilize the warm amber accent (`#f5b942`) with dark near-black text for high contrast. Secondary actions rely on the elevated surface tone (`#181b22`) paired with subtle borders (`#272a30`) and soft off-white labels. States must be clearly articulated through subtle luminance shifts rather than scale transforms.

### Input Fields
Inputs feature the elevated surface background, a 12px rounded corner, and subtle border outlines. Focus states transition the border smoothly to the warm amber accent, accompanied by a muted gray placeholder text.

### Cards
Media and editorial cards are housed in `#181b22` containers with 12px corners and subtle borders. Image assets stretch flush to the card's top edge, with typography and metadata nested below within generous padded containers.

### Chips & Tags
Compact metadata filters and genre tags use pill or 6px rounded shapes, rendered in low-contrast surface tones with uppercase tracking. Active filter states invert to solid amber or high-contrast borders.

### Checkboxes & Radios
Custom controls feature clean square/circular geometry with crisp borders, utilizing the warm amber accent for checked or selected states.

### Specialized Components
- **Hero Banners:** Immersive edge-to-edge cinematic backdrops featuring gradient scrims that blend smoothly into the near-black background.
- **Timeline / Scene Scubbers:** Minimalist single-pixel tracks with amber progress indicators and floating editorial chapter markers.